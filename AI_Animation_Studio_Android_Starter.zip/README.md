# AI Animation Studio — Android starter

Kotlin + Jetpack Compose Android Studio project.

Included:
- Dark studio interface
- Android image picker
- Arcane-inspired, anime, 3D animation, LEGO, watercolor and comic-book style choices
- Editable prompt and style-strength slider
- Frame workflow UI

**AI rendering is not connected yet.** This project is an Android UI starter, not a complete AI renderer. To generate images, connect a backend that accepts the source image, style, prompt and strength, then returns the generated image. Keep provider API keys on the backend, never inside the APK.

## Build
1. Install Android Studio.
2. Open this project folder.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging or use an emulator.
5. Press Run.

Package: `com.example.aianimationstudio`  
Minimum Android: 8.0 (API 26)
