package com.example.aianimationstudio

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val bg = Color(0xFF11101A)
private val panel = Color(0xFF1D1B2A)
private val violet = Color(0xFF9B78FF)
private val muted = Color(0xFFAAA6BC)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { StudioScreen() }
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
 var imageUri by remember { mutableStateOf<Uri?>(null) }
 var style by remember { mutableStateOf("Arcane-inspired") }
 var prompt by remember { mutableStateOf("Transform this image into a richly painted cinematic animation frame. Preserve the subject, pose, composition and important details.") }
 var status by remember { mutableStateOf("Choose an image to begin") }
 var strength by remember { mutableFloatStateOf(0.72f) }
 val styles = listOf("Arcane-inspired","Anime","3D animation","LEGO stop-motion","Watercolor","Comic-book")
 val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
  if (uri != null) { imageUri = uri; status = "Image selected. Connect an AI backend to render it." }
 }
 MaterialTheme(colorScheme = darkColorScheme(primary=violet, background=bg, surface=panel, onBackground=Color.White, onSurface=Color.White)) {
  Scaffold(containerColor=bg) { padding ->
   Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
    Row(verticalAlignment=Alignment.CenterVertically) {
     Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(violet,Color(0xFF4ED7D0)))), contentAlignment=Alignment.Center) { Icon(Icons.Default.Movie,null,tint=Color.White) }
     Spacer(Modifier.width(12.dp))
     Column(Modifier.weight(1f)) { Text("AI ANIMATION STUDIO",fontSize=18.sp,fontWeight=FontWeight.Black); Text("Turn frames into cinematic art",color=muted,fontSize=12.sp) }
     Text("BETA",color=violet,fontWeight=FontWeight.Bold,fontSize=11.sp)
    }
    Text("SOURCE FRAME",color=muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(20.dp)).background(panel).border(1.dp,Color(0xFF39334D),RoundedCornerShape(20.dp)),contentAlignment=Alignment.Center) {
     if (imageUri != null) AsyncImage(model=imageUri,contentDescription="Selected frame",modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
     else Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.AddPhotoAlternate,null,tint=violet,modifier=Modifier.size(42.dp)); Text("Upload an image or video frame"); Text("PNG • JPG • WEBP",color=muted,fontSize=12.sp) }
    }
    Button(onClick={picker.launch("image/*")},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) { Icon(Icons.Default.AddPhotoAlternate,null); Spacer(Modifier.width(8.dp)); Text(if(imageUri==null) "Choose image" else "Change image") }
    Text("ART STYLE",color=muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    styles.chunked(2).forEach { pair ->
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      pair.forEach { item ->
       val selected=style==item
       Surface(onClick={style=item},modifier=Modifier.weight(1f),color=if(selected) Color(0xFF352A55) else panel,shape=RoundedCornerShape(12.dp),border=androidx.compose.foundation.BorderStroke(1.dp,if(selected) violet else Color(0xFF39334D))) {
        Text(item,Modifier.padding(12.dp),color=if(selected) Color.White else muted,fontSize=12.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
       }
      }
      if(pair.size==1) Spacer(Modifier.weight(1f))
     }
    }
    Text("PROMPT",color=muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    OutlinedTextField(value=prompt,onValueChange={prompt=it},modifier=Modifier.fillMaxWidth(),minLines=3,shape=RoundedCornerShape(14.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=violet,unfocusedBorderColor=Color(0xFF39334D)))
    Row(verticalAlignment=Alignment.CenterVertically) { Text("STYLE STRENGTH",color=muted,fontSize=11.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("${(strength*100).toInt()}%",color=violet,fontWeight=FontWeight.Bold) }
    Slider(value=strength,onValueChange={strength=it})
    Button(onClick={status=if(imageUri==null) "Please choose an image first" else "Ready to render. Connect an AI generation backend/API to enable rendering."},modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(15.dp)) {
     Icon(Icons.Default.AutoAwesome,null); Spacer(Modifier.width(8.dp)); Text("GENERATE FRAME",fontWeight=FontWeight.Bold)
    }
    Text(status,color=muted,fontSize=12.sp)
    HorizontalDivider(color=Color(0xFF39334D))
    Text("FRAME WORKFLOW",fontWeight=FontWeight.Bold)
    Text("Import frames one at a time, use the same style and character reference, then render and export them in sequence. Batch queue and video export can be added with a generation backend.",color=muted,fontSize=13.sp,lineHeight=19.sp)
    OutlinedButton(onClick={status="Export becomes available after a frame has been generated."},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) { Icon(Icons.Default.Download,null); Spacer(Modifier.width(8.dp)); Text("EXPORT RENDERED FRAME") }
    Text("AI rendering is not connected yet. This starter includes the Android interface and image picker. A hosted image-generation API/model is required for actual rendering. Keep private API keys on a backend, not inside the APK.",color=Color(0xFF817C91),fontSize=11.sp,lineHeight=16.sp)
   }
  }
 }
}
