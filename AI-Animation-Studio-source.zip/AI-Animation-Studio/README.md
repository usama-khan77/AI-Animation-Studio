# AI Animation Studio — starter Android project

This is a fresh native Android starter for selecting multiple photos and processing them sequentially offline.

## Current functionality
- Select multiple images using Android's document picker.
- Process one image at a time to reduce memory use.
- Show batch progress.
- Save JPEG results in `Pictures/AI Animation Studio`.

## Important limitation
The current painterly treatment is a basic offline pixel-processing effect. It is **not** a neural-network AI model and does not generate a true Arcane-like transformation. A compatible, licensed on-device model and inference runtime still need to be selected, added, and tested on the target phone.

## Build
Push this project to the `main` branch of the GitHub repository. GitHub Actions builds a debug APK. Open the Actions tab, select the successful run, and download the `AI-Animation-Studio-debug` artifact ZIP. Extract it and install the APK on Android.
